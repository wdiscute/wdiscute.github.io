package com.wdiscute.utils;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.FileToIdConverter;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.GsonHelper;
import net.minecraft.util.profiling.ProfilerFiller;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public record DataEntry<T>(Identifier rl, Codec<T> codec)
{
    private static final Gson GSON = new Gson();
    public static final Map<DataEntry<?>, Object> MAP = new HashMap<>();
    public static final Map<Identifier, DataEntry<?>> SYNC_ENTRIES_BY_ID = new HashMap<>();
    public static final Map<DataEntry<?>, StreamCodec<RegistryFriendlyByteBuf, ?>> STREAM_CODECS = new HashMap<>();

    @SuppressWarnings("unchecked")
    public T get()
    {
        return (T) MAP.get(this);
    }

    public DataEntry<T> sync(StreamCodec<RegistryFriendlyByteBuf, T> streamCodec)
    {
        STREAM_CODECS.put(this, streamCodec);
        SYNC_ENTRIES_BY_ID.put(rl, this);
        return this;
    }

    public static <T> DataEntry<T> register(Identifier rl, Codec<T> codec, T defaultValue)
    {
        DataEntry<T> entry = new DataEntry<>(rl, codec);
        MAP.put(entry, defaultValue);
        return entry;
    }

    public static class DataEntryReloadListener extends SimplePreparableReloadListener<Map<DataEntry<?>, Object>>
    {
        @Override
        protected Map<DataEntry<?>, Object> prepare(ResourceManager resourceManager, ProfilerFiller profiler)
        {
            Map<DataEntry<?>, Object> values = new HashMap<>(DataEntry.MAP);

            for (DataEntry<?> entry : DataEntry.MAP.keySet())
            {
                Identifier file = Utils.rl(entry.rl().getNamespace(), entry.rl().getPath() + ".json");

                resourceManager.getResource(file).ifPresent(resource ->
                {
                    try (BufferedReader reader = resource.openAsReader())
                    {
                        JsonElement json = GsonHelper.fromJson(GSON, reader, JsonElement.class);

                        DataResult<?> result = entry.codec().parse(JsonOps.INSTANCE, json);

                        //if parsed correctly put new value, otherwise put old value
                        result.resultOrPartial(error -> LogUtils.getLogger().error("Failed to parse {}: {}", entry.rl, error))
                                .ifPresentOrElse(value -> values.put(entry, value), () -> values.put(entry, MAP.get(entry)));

                    } catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                });
            }
            return values;
        }

        @Override
        protected void apply(Map<DataEntry<?>, Object> values, ResourceManager resourceManager, ProfilerFiller profiler)
        {
            DataEntry.MAP.clear();
            DataEntry.MAP.putAll(values);
        }
    }

    public record MultiEntry<T>(Identifier path, Codec<ListOperation<T>> codec)
    {
        private static final Gson GSON = new Gson();
        public static final Map<MultiEntry<?>, List<?>> MAP = new HashMap<>();
        public static final Map<Identifier, MultiEntry<?>> SYNC_ENTRIES_BY_ID = new HashMap<>();
        public static final Map<MultiEntry<?>, StreamCodec<RegistryFriendlyByteBuf, ?>> STREAM_CODECS = new HashMap<>();

        @SuppressWarnings("unchecked")
        public List<T> get()
        {
            return (List<T>) MAP.get(this);
        }

        public static <T> MultiEntry<T> register(Identifier path, Codec<T> codec)
        {
            MultiEntry<T> entry = new MultiEntry<>(path, ListOperation.codec(codec));

            MAP.put(entry, List.of());

            return entry;
        }

        public MultiEntry<T> sync(StreamCodec<RegistryFriendlyByteBuf, T> streamCodec)
        {
            STREAM_CODECS.put(this, streamCodec);
            SYNC_ENTRIES_BY_ID.put(path, this);
            return this;
        }

        public record ListOperation<T>(List<T> add, List<T> remove)
        {
            public static <T> Codec<ListOperation<T>> codec(Codec<T> codec)
            {
                return RecordCodecBuilder.create(instance -> instance.group(
                        codec.listOf().optionalFieldOf("add", List.of()).forGetter(ListOperation::add),
                        codec.listOf().optionalFieldOf("remove", List.of()).forGetter(ListOperation::remove)
                ).apply(instance, ListOperation::new));
            }
        }

        public static class ListDataEntryReloadListener extends SimplePreparableReloadListener<Map<MultiEntry<?>, List<?>>>
        {
            @SuppressWarnings("unchecked")
            @Override
            protected Map<MultiEntry<?>, List<?>> prepare(ResourceManager resourceManager, ProfilerFiller profiler)
            {
                Map<MultiEntry<?>, List<?>> values = new HashMap<>();

                //for each registered data entry
                for (MultiEntry<?> dataEntry : MultiEntry.MAP.keySet())
                {
                    var availableJsons = FileToIdConverter.json(dataEntry.path.getNamespace())
                            .listMatchingResourceStacks(resourceManager)
                            .entrySet()
                            .stream()
                            .filter(o -> o.getKey().getPath()
                                    .equals(dataEntry.path.getNamespace() + "/" + dataEntry.path.getPath() + ".json"))
                            .toList();

                    availableJsons.forEach(System.out::println);

                    var availableResources = availableJsons
                            .stream()
                            .flatMap(o -> o.getValue().stream().findAny().stream())
                            .toList();

                    List currentList = new ArrayList<>();
                    List<JsonElement> currentJsons = new ArrayList<>();
                    List<JsonElement> removalJsons = new ArrayList<>();

                    for (Resource resource : availableResources)
                    {
                        try (BufferedReader reader = resource.openAsReader())
                        {
                            JsonElement json = GsonHelper.fromJson(GSON, reader, JsonElement.class);
                            JsonObject jsonObject = json.getAsJsonObject();

                            JsonArray removeArray = jsonObject.getAsJsonArray("remove");

                            if (removeArray != null)
                                for (JsonElement removalJson : removeArray)
                                    removalJsons.add(removalJson.deepCopy());

                            var result = dataEntry.codec().parse(JsonOps.INSTANCE, json);

                            result.resultOrPartial(error -> LogUtils.getLogger().error("Failed to parse {}: {}", dataEntry.path, error)
                            ).ifPresent(operation ->
                            {
                                currentList.addAll(operation.add());

                                JsonArray addArray = jsonObject.getAsJsonArray("add");

                                if (addArray != null)
                                    for (JsonElement additionJson : addArray)
                                        currentJsons.add(additionJson.deepCopy());
                            });
                        }
                        catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }

                    for (int i = currentList.size() - 1; i >= 0; i--)
                    {
                        JsonElement currentJson = currentJsons.get(i);

                        if (removalJsons.stream().anyMatch(removalJson -> removalJson.equals(currentJson)))
                        {
                            currentList.remove(i);
                            currentJsons.remove(i);
                        }
                    }

                    values.put(dataEntry, currentList);
                }

                return values;
            }

            @Override
            protected void apply(Map<MultiEntry<?>, List<?>> values, ResourceManager resourceManager, ProfilerFiller profiler)
            {
                MultiEntry.MAP.putAll(values);
            }
        }
    }
}
